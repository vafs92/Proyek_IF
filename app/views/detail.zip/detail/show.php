<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>

<h1>Detail Barang</h1>
<p>Kode Barang: <?= $data['barang']['kodeB'] ?></p>
<p>Nama Barang: <?= $data['barang']['namaB'] ?></p>
<body>
    <img src="<?= BASEURL; ?>/foto/<?= $data['barang']['foto']; ?>" alt="Foto Barang" width="200">
</body>
<br>
<a href="<?= BASEURL; ?>/perekaman/barang">Kembali</a>
</br>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>

<body>
    <img src="<?= BASEURL; ?>/foto/<?= $data['barang']['foto']; ?>" alt="Foto Barang" width="200">
</body>
<br>
<a href="<?= BASEURL; ?>/perekaman/tabelBarang">Kembali</a>
</br>
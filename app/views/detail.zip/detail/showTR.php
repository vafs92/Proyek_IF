<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>

<body>
    <img src="<?= BASEURL; ?>/foto/<?= $data['ruang']['foto']; ?>" alt="Foto Ruang" width="200">
</body>
<br>
<a href="<?= BASEURL; ?>/perekaman/tabelRuang">Kembali</a>
</br>